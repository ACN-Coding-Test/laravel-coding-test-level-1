<!DOCTYPE html>
<html>
<head>
    <title>Testing</title>
</head>
<body>
    <h1>{{ $title }}</h1>
    <p>{{ $body }}</p>
     
    <p>Thank you</p>
</body>
</html>