<!DOCTYPE html>
<html>
<head>
    <title>Testing</title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($body); ?></p>
     
    <p>Thank you</p>
</body>
</html><?php /**PATH E:\GITHUB\accenturephp\laravel-coding-test-level-1\resources\views/notification.blade.php ENDPATH**/ ?>